#include "bench.cuh"
#include "megakernel.cuh"
#include "frontier.cuh"
#include <cmath>
#include <limits>
#include <numeric>
#include <random>

using namespace nano;

struct Inputs {
    int tokens, heads, d, v, window;
    float scale;
    std::vector<int> seq;
    std::vector<bf16> q, k, value, dy;
    Inputs(std::vector<int> lengths, int qk_dim, int v_dim, int w, bool paired, int pattern)
        : tokens(std::accumulate(lengths.begin(), lengths.end(), 0) * (paired ? 2 : 1)),
          heads(paired ? 3 : frontier::heads), d(qk_dim), v(v_dim), window(w),
          scale(1.0f / std::sqrt(float(d))), seq{0},
          q(tokens * heads * d), k(q.size()), value(tokens * heads * v), dy(value.size()) {
        for (int n : lengths)
            seq.push_back(seq.back() + n * (paired ? 2 : 1));
        std::mt19937 rng(417 + tokens + d + v);
        std::normal_distribution<float> normal;
        for (auto *buffer : {&q, &k, &value, &dy})
            for (auto &x : *buffer)
                x = __float2bfloat16_rn(normal(rng) * 0.4f);
        if (pattern == 1) {
            std::fill(q.begin(), q.end(), bf16(0.0f));
            std::fill(k.begin(), k.end(), bf16(0.0f));
        } else if (pattern == 2) {
            for (auto *buffer : {&q, &k})
                for (auto &x : *buffer)
                    x = bf16(float(x) * 8.0f);
        }
    }
};

struct Reference {
    std::vector<double> y, dq, dk, dv, lse, delta;
    explicit Reference(const Inputs &in)
        : y(in.value.size()), dq(in.q.size()), dk(in.q.size()), dv(in.value.size()),
          lse(in.tokens * in.heads), delta(lse.size()) {
        // Materialize each probability row in FP64, independently of the device's
        // online recurrence and key-owned backward traversal.
        for (size_t doc = 1; doc < in.seq.size(); ++doc)
            for (int t = in.seq[doc - 1]; t < in.seq[doc]; ++t)
                for (int h = 0; h < in.heads; ++h) {
                    const int start = std::max(in.seq[doc - 1], t - in.window);
                    const size_t qi = (size_t(t) * in.heads + h) * in.d;
                    const size_t vi = (size_t(t) * in.heads + h) * in.v;
                    const int si = t * in.heads + h;
                    std::vector<double> p(t - start + 1);
                    for (int j = start; j <= t; ++j) {
                        size_t ki = (size_t(j) * in.heads + h) * in.d;
                        double dot = 0;
                        for (int c = 0; c < in.d; ++c)
                            dot += double(float(in.q[qi + c])) * float(in.k[ki + c]);
                        p[j - start] = dot * in.scale;
                    }
                    const double maximum = *std::max_element(p.begin(), p.end());
                    double sum = 0;
                    for (auto &x : p) {
                        x = std::exp(x - maximum);
                        sum += x;
                    }
                    lse[si] = maximum + std::log(sum);
                    for (auto &x : p)
                        x /= sum;
                    for (int j = start; j <= t; ++j) {
                        size_t kv = (size_t(j) * in.heads + h) * in.v;
                        for (int c = 0; c < in.v; ++c)
                            y[vi + c] += p[j - start] * float(in.value[kv + c]);
                    }
                    for (int c = 0; c < in.v; ++c)
                        delta[si] += double(float(bf16(float(y[vi + c])))) * float(in.dy[vi + c]);
                    for (int j = start; j <= t; ++j) {
                        size_t ki = (size_t(j) * in.heads + h) * in.d;
                        size_t kv = (size_t(j) * in.heads + h) * in.v;
                        double dp = 0;
                        for (int c = 0; c < in.v; ++c) {
                            dp += double(float(in.dy[vi + c])) * float(in.value[kv + c]);
                            dv[kv + c] += p[j - start] * float(in.dy[vi + c]);
                        }
                        double ds = p[j - start] * (dp - delta[si]) * in.scale;
                        for (int c = 0; c < in.d; ++c) {
                            dq[qi + c] += ds * float(in.k[ki + c]);
                            dk[ki + c] += ds * float(in.q[qi + c]);
                        }
                    }
                }
    }
};

struct Buffers {
    DeviceBuffer<bf16> q, k, v, dy, y, dq, dk, dv;
    DeviceBuffer<float> raw_y, raw_dq, raw_dk, raw_dv, lse, delta;
    DeviceBuffer<int> seq;
    Attention a;
    explicit Buffers(const Inputs &in)
        : q(in.q.size()), k(in.k.size()), v(in.value.size()), dy(in.dy.size()), y(v.n),
          dq(q.n), dk(k.n), dv(v.n), raw_y(v.n), raw_dq(q.n), raw_dk(k.n), raw_dv(v.n),
          lse(in.tokens * in.heads), delta(lse.n), seq(in.seq.size()),
          a{q.p, k.p, v.p, dy.p, y.p, dq.p, dk.p, dv.p, lse.p, delta.p, seq.p,
            in.tokens, in.heads, in.d, in.v, int(in.seq.size() - 1), in.window, in.scale,
            raw_y.p, raw_dq.p, raw_dk.p, raw_dv.p} {
        q.put(in.q); k.put(in.k); v.put(in.value); dy.put(in.dy); seq.put(in.seq);
    }
    void poison() {
        for (auto *b : {&y, &dq, &dk, &dv})
            CHECK_CUDA(cudaMemset(b->p, 0xff, b->n * sizeof(bf16)));
        for (auto *b : {&raw_y, &raw_dq, &raw_dk, &raw_dv, &lse, &delta})
            CHECK_CUDA(cudaMemset(b->p, 0xff, b->n * sizeof(float)));
    }
};

__global__ void staged_attention(Attention a, TaskKind kind) {
    execute_attention(a, kind, blockIdx.x, blockIdx.y);
}

__global__ void reset_attention_state(int *p, int roots, int count) {
    p[0] = roots; p[1] = roots; p[2] = count; p[3] = 0;
}

// Includes a dependent GEMM to exercise both operation families in one launch.
// Its output is a scheduler sentinel, not an attention output projection.
struct Schedule {
    int count, roots;
    std::vector<int> initial;
    DeviceBuffer<Task> tasks;
    DeviceBuffer<Group> groups;
    DeviceBuffer<int> counters, queue, state, audit, device_initial;
    DeviceBuffer<Attention> attention;
    DeviceBuffer<Matmul> matmul;
    DeviceBuffer<fp8> ma, mb;
    DeviceBuffer<bf16> mc;
    explicit Schedule(const Attention &a)
        : count(((a.tokens + 3) / 4) * a.heads * 3 + 1), roots((count - 1) / 3),
          initial(count, 0), tasks(count), groups(roots + 2), counters(groups.n),
          queue(count), state(4), audit(count + 2), device_initial(count), attention(1),
          matmul(2), ma(64 * 64), mb(ma.n), mc(ma.n) {
        std::vector<Task> ts;
        std::vector<Group> gs(roots + 2);
        for (int pass = 0; pass < 3; ++pass)
            for (int r = 0; r < (a.tokens + 3) / 4; ++r)
                for (int h = 0; h < a.heads; ++h) {
                    int i = r * a.heads + h;
                    auto kind = pass == 0 ? TaskKind::attention_forward :
                                pass == 1 ? TaskKind::attention_dq : TaskKind::attention_dkv;
                    int group = pass == 0 ? i : pass == 1 ? roots : roots + 1;
                    ts.push_back({0, r, h, {group, -1}, 0, 0, kind});
                    if (pass == 0) {
                        initial[i] = i + 1;
                        gs[i] = {1, roots + i, roots + i + 1};
                    }
                }
        gs[roots] = {roots, 2 * roots, 3 * roots};
        gs[roots + 1] = {roots, 3 * roots, 3 * roots + 1};
        ts.push_back({1, 0, 0, {-1, -1}});
        std::mt19937 rng(829);
        std::shuffle(initial.begin(), initial.begin() + roots, rng);
        tasks.put(ts); groups.put(gs); attention.put({a}); device_initial.put(initial);
        ma.put(std::vector<fp8>(ma.n, fp8(0.125f)));
        std::vector<fp8> identity(mb.n, fp8(0.0f));
        for (int i = 0; i < 64; ++i)
            identity[i * 64 + i] = fp8(1.0f);
        mb.put(identity);
        Matmul m{ma.p, mb.p, nullptr, nullptr, mc.p, 64, 64, 64, 64, 1, 64, 1,
                 1.0f, 1.0f, 1.0f, Epilogue::linear};
        matmul.put({m, m});
    }
    void reset() {
        CHECK_CUDA(cudaMemsetAsync(counters.p, 0, counters.n * sizeof(int)));
        CHECK_CUDA(cudaMemcpyAsync(queue.p, device_initial.p, count * sizeof(int), cudaMemcpyDeviceToDevice));
        reset_attention_state<<<1, 1>>>(state.p, roots, count);
    }
    Graph graph(bool checked) {
        return {matmul.p, tasks.p, groups.p, counters.p, queue.p, state.p, count, roots,
                checked ? audit.p : nullptr, attention.p};
    }
    void verify() {
        for (auto x : mc.get())
            if (float(x) != 0.125f)
                throw std::runtime_error("mixed graph GEMM sentinel mismatch");
        if (state.get()[2] != 0)
            throw std::runtime_error("unfinished tasks");
    }
};

void check(const char *name, const std::vector<float> &actual, const std::vector<double> &ref) {
    double error = 0, norm = 0, maximum = 0;
    for (size_t i = 0; i < ref.size(); ++i) {
        double e = double(actual[i]) - ref[i];
        if (!std::isfinite(actual[i]))
            throw std::runtime_error(std::string(name) + " non-finite output");
        error += e * e;
        norm += ref[i] * ref[i];
        maximum = std::max(maximum, std::abs(e));
    }
    double relative = std::sqrt(error / std::max(norm, 1e-30));
    printf("%s rel_l2=%.9g max_abs=%.9g\n", name, relative, maximum);
    if (relative > 0.0002 && maximum > 0.00002)
        throw std::runtime_error(std::string(name) + " FP64 reference mismatch");
}

void check_rounded(const char *name, const std::vector<bf16> &actual, const std::vector<float> &raw) {
    for (size_t i = 0; i < actual.size(); ++i)
        if (float(actual[i]) != float(bf16(raw[i])))
            throw std::runtime_error(std::string(name) + " BF16 rounding mismatch");
}

void validate(const Inputs &in, int workers) {
    printf("attention tokens=%d heads=%d qk=%d v=%d window=%d documents=%zu workers=%d\n",
           in.tokens, in.heads, in.d, in.v, in.window, in.seq.size() - 1, workers);
    Buffers b(in);
    Schedule s(b.a);
    Reference ref(in);
    b.poison();
    CHECK_CUDA(cudaMemset(s.mc.p, 0xff, s.mc.n * sizeof(bf16)));
    CHECK_CUDA(cudaMemset(s.audit.p, 0, s.audit.n * sizeof(int)));
    s.reset();
    megakernel<true, false, true><<<workers, threads>>>(s.graph(true));
    CHECK_CUDA(cudaGetLastError());
    CHECK_CUDA(cudaDeviceSynchronize());
    auto visits = s.audit.get();
    for (int i = 0; i < s.count; ++i)
        if (visits[i] != 1)
            throw std::runtime_error("task not executed exactly once");
    s.verify();
    auto y = b.raw_y.get(), dq = b.raw_dq.get(), dk = b.raw_dk.get(), dv = b.raw_dv.get();
    check("y", y, ref.y); check("dq", dq, ref.dq); check("dk", dk, ref.dk); check("dv", dv, ref.dv);
    check("lse", b.lse.get(), ref.lse); check("delta", b.delta.get(), ref.delta);
    check_rounded("y", b.y.get(), y); check_rounded("dq", b.dq.get(), dq);
    check_rounded("dk", b.dk.get(), dk); check_rounded("dv", b.dv.get(), dv);
    // Reuse poisoned storage and compare the unaudited worker with separate
    // launches. This catches readiness bugs masked by instrumentation.
    for (int repeat = 0; repeat < 2; ++repeat) {
        b.poison(); s.reset();
        megakernel<false, false, true><<<workers, threads>>>(s.graph(false));
        CHECK_CUDA(cudaGetLastError());
        if (b.raw_y.get() != y || b.raw_dq.get() != dq || b.raw_dk.get() != dk || b.raw_dv.get() != dv)
            throw std::runtime_error("production reuse mismatch");
        s.verify();
    }
    b.poison();
    dim3 grid((in.tokens + 3) / 4, in.heads);
    for (auto kind : {TaskKind::attention_forward, TaskKind::attention_dq, TaskKind::attention_dkv})
        staged_attention<<<grid, threads>>>(b.a, kind);
    CHECK_CUDA(cudaGetLastError());
    if (b.raw_y.get() != y || b.raw_dq.get() != dq || b.raw_dk.get() != dk || b.raw_dv.get() != dv)
        throw std::runtime_error("staged versus persistent mismatch");
}

void benchmark(int d, int v, int workers) {
    std::vector<int> lengths(18, 896);
    lengths.push_back(16384 - 18 * 896);
    Inputs in(lengths, d, v, 384, false, 0);
    Buffers b(in);
    b.a.raw_y = b.a.raw_dq = b.a.raw_dk = b.a.raw_dv = nullptr;
    Schedule s(b.a);
    printf("timing scalar attention baseline tokens=%d qk=%d v=%d window=%d; no FA3 speed claim\n",
           in.tokens, d, v, in.window);
    dim3 grid((in.tokens + 3) / 4, in.heads);
    device_time("staged_forward_backward", [&] {
        for (auto kind : {TaskKind::attention_forward, TaskKind::attention_dq, TaskKind::attention_dkv})
            staged_attention<<<grid, threads>>>(b.a, kind);
    });
    device_time("persistent_forward_backward_plus_reset_and_sentinel", [&] {
        s.reset();
        megakernel<false, false, true><<<workers, threads>>>(s.graph(false));
    });
    CHECK_CUDA(cudaGetLastError());
    s.verify();
}

int main(int argc, char **argv) {
    try {
        bool quick = argc > 1 && std::string(argv[1]) == "--quick";
        device_info();
        cudaDeviceProp p;
        CHECK_CUDA(cudaGetDeviceProperties(&p, 0));
        int resident;
        CHECK_CUDA(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
            &resident, megakernel<false, false, true>, threads, 0));
        printf("mixed worker resident_ctas_per_sm=%d\n", resident);
        for (auto shape : {std::pair{64, 128}, std::pair{64, 64}, std::pair{128, 128}}) {
            validate(Inputs({1, 7, 13}, shape.first, shape.second, 8, false, 0), 1);
            validate(Inputs({1, 3, 19}, shape.first, shape.second, 5, true, 1), 7);
            if (!quick) {
                validate(Inputs({1, 15, 65, 176}, shape.first, shape.second, 128, false, 0), p.multiProcessorCount);
                validate(Inputs({1, 3, 19}, shape.first, shape.second, 0, false, 0), 7);
                validate(Inputs({1, 127, 385}, shape.first, shape.second, 1536, true, 2), p.multiProcessorCount * 4);
                benchmark(shape.first, shape.second, p.multiProcessorCount * resident);
            }
        }
        puts("PASS: native attention math and mixed persistent scheduling; full model and FA3 parity remain unverified");
        return 0;
    } catch (const std::exception &e) {
        fprintf(stderr, "FAIL: %s\n", e.what());
        return 1;
    }
}
